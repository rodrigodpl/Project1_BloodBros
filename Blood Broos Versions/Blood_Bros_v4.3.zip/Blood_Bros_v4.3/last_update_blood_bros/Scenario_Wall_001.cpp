#include "Application.h"
#include "Scenario_Wall_001.h"
#include "Path.h"
#include "ModuleCollision.h"
#include "p2Point.h"
#include "ModuleParticles.h"

Scenario_Wall_001::Scenario_Wall_001(int x, int y) : Scenario_elem(x, y)
{

	health_100.PushBack({ 31, 231, 499, 255 });

	health_100_hit.PushBack({ 0, 0, 0, 0 });
	health_100_hit.PushBack({ 0, 0, 0, 0 });
	health_100_hit.PushBack({ 0, 0, 0, 0 });
	health_100_hit.speed = 0.2f;

	health_60.PushBack({ 0, 0, 0, 0 });

	health_60_hit.PushBack({ 0, 0, 0, 0 });
	health_60_hit.PushBack({ 0, 0, 0, 0 });
	health_60_hit.PushBack({ 0, 0, 0, 0 });
	health_60_hit.speed = 0.2f;

	health_30.PushBack({ 0, 0, 0, 0 });

	health_30_hit.PushBack({ 0, 0, 0, 0 });
	health_30_hit.PushBack({ 0, 0, 0, 0 });
	health_30_hit.PushBack({ 0, 0, 0, 0 });
	health_30_hit.speed = 0.2f;

	collider = App->collision->AddCollider({ 0, 0, 499, 255 }, COLLIDER_TYPE::COLLIDER_WALL, (Module*)App->scenario);

	orig_pos.x = x;
	orig_pos.y = y;

	health = 1000;

	animation = &health_100;
}

void Scenario_Wall_001::Update()
{

	Animation* state = &health_100;;

	if (!being_hit){

		if (health <= 1000){

			if (health < 600){

				if (health < 300){
					state = &health_30;
				}
				else{
					state = &health_60;
				}
			}
		}
	}
	else{
		if (health <= 10000){
			state = &health_100_hit;

			if (health < 600){

				if (health < 300){
					state = &health_30_hit;
				}
				else{
					state = &health_60_hit;
				}
			}
		}
	}

	animation = state;
	being_hit = false;
	
}

void Scenario_Wall_001::Destroy(){

	App->particles->AddParticle(App->particles->destroying_wall, position.x, position.y);


}