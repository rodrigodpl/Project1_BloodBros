#include "Application.h"
#include "Scenario_Bottle.h"
#include "Path.h"
#include "ModuleCollision.h"
#include "p2Point.h"
#include "ModuleParticles.h"
#include <stdlib.h>
#include <time.h>

Scenario_Bottle::Scenario_Bottle(int x, int y) : Scenario_elem(x, y)
{

	blue_wide_bottle.PushBack({ 30, 27, 44, 46 });
	blue_narrow_bottle.PushBack({ 86, 27, 35, 48 });
	orange_bottle.PushBack({ 134, 27, 35, 48 });


	collider = App->collision->AddCollider({ 0, 0, 40, 45 }, COLLIDER_TYPE::COLLIDER_WALL, (Module*)App->scenario);

	orig_pos.x = x;
	orig_pos.y = y;

	health = 10;

	srand(time(NULL));

	uint bottle_kind = ((rand()) % 3);
	
	switch (bottle_kind){
	case BLUE_WIDE:
		animation = &blue_wide_bottle;
		break;
	case BLUE_NARROW:
		animation = &blue_narrow_bottle;
		break;
	case ORANGE:
		animation = &orange_bottle;
		break;

	}
	
}


void Scenario_Bottle::Destroy(){

	App->particles->AddParticle(App->particles->laser, position.x, position.y);


}