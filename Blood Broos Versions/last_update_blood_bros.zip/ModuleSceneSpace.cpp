#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleAudio.h"
#include "ModuleRender.h"
#include "ModulePlayer.h"
#include "ModuleCollision.h"
#include "ModuleParticles.h"
#include "ModuleEnemies.h"
#include "ModuleReticle.h"
#include "ModuleSceneSpace.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModuleSceneSpace::ModuleSceneSpace()
{}

ModuleSceneSpace::~ModuleSceneSpace()
{}

// Load assets
bool ModuleSceneSpace::Start()
{
	LOG("Loading space scene");
	
	background = App->textures->Load("rtype/background.png");

	App->player->Enable();
	App->particles->Enable();
	App->collision->Enable();
	App->enemies->Enable();
	App->reticle->Enable();

	App->audio->PlayMusic("rtype/stage1.ogg", 1.0f);
	
	// Colliders ---
	uint i = 0;
	wall[i++] = App->collision->AddCollider({0, 224, 3930, 16}, COLLIDER_WALL, this);
	wall[i++] = App->collision->AddCollider({ 1375, 0, 111, 96 }, COLLIDER_WALL, this);
	wall[i++] = App->collision->AddCollider({ 1375, 145, 111, 96 }, COLLIDER_WALL, this);

	// Enemies ---
	
	
	// TODO 1: Add a new wave of red birds
	
	return true;
}

// UnLoad assets
bool ModuleSceneSpace::CleanUp()
{
	LOG("Unloading space scene");

 	App->textures->Unload(background);

	App->enemies->Disable();
	App->collision->Disable();
	App->particles->Disable();
	App->player->Disable();
	App->reticle->Disable();

	return true;
}

// Update: draw background
update_status ModuleSceneSpace::Update()
{
	

	// Draw everything --------------------------------------
	App->render->Blit(background, 0, 0, NULL);
	
	return UPDATE_CONTINUE;
}

void ModuleSceneSpace::OnCollision(Collider* c1, Collider* c2){

	if (App->reticle->shooting){

		wall_health -= 50;

		if (wall_health <= 0){
			uint i;
			for (i = 0; i < WALL_COLLIDERS; i++){
				App->collision->EraseCollider(wall[i]);
			}


		}
	}



}