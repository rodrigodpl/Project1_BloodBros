#ifndef __MODULESCENESPACE_H__
#define __MODULESCENESPACE_H__

#include "Module.h"

#define WALL_COLLIDERS 3

struct SDL_Texture;

class ModuleSceneSpace : public Module
{
public:
	ModuleSceneSpace();
	~ModuleSceneSpace();

	bool Start();
	update_status Update();
	bool CleanUp();

public:
	
	SDL_Texture* background = nullptr;
	SDL_Texture* stars = nullptr;
	void OnCollision(Collider* c1, Collider* c2);
	int wall_health = 1000;
	Collider* wall[WALL_COLLIDERS];
};

#endif // __MODULESCENESPACE_H__