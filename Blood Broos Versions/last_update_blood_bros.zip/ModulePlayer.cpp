#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleParticles.h"
#include "ModuleRender.h"
#include "ModuleCollision.h"
#include "ModuleFadeToBlack.h"
#include "ModulePlayer.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModulePlayer::ModulePlayer()
{
	// idle animation (just the ship)
	idle.PushBack({66, 1, 32, 14});
	
	// Move left
	left.PushBack({205, 24, 34, 94});
	left.PushBack({159, 24, 34, 94});
	left.PushBack({0, 0, 0, 0});
	left.loop = false;
	left.speed = 0.3f;

	// Move right
	right.PushBack({83, 18, 38, 77});
	right.PushBack({133, 18, 43, 73});
	right.PushBack({0, 0, 0, 0});
	right.loop = false;
	right.speed = 0.3f;

	crouched_idle.PushBack({ 0, 0, 0, 0 });
	crouched_idle.PushBack({ 0, 0, 0, 0 });
	crouched_idle.loop = false;
	crouched_idle.speed = 0.3f;

	crouched_left.PushBack({ 0, 0, 0, 0 });
	crouched_left.PushBack({ 0, 0, 0, 0 });
	crouched_left.loop = false;
	crouched_left.speed = 0.3f;

	crouched_right.PushBack({ 0, 0, 0, 0 });
	crouched_right.PushBack({ 0, 0, 0, 0 });
	crouched_right.loop = false;
	crouched_right.speed = 0.3f;

	crouched_roll_right.PushBack({ 0, 0, 0, 0 });
	crouched_roll_right.PushBack({ 0, 0, 0, 0 });
	crouched_roll_right.loop = false;
	crouched_roll_right.speed = 0.3f;	

	crouched_roll_right.PushBack({ 0, 0, 0, 0 });
	crouched_roll_right.PushBack({ 0, 0, 0, 0 });
	crouched_roll_right.loop = false;
	crouched_roll_right.speed = 0.3f;

	jump_roll_right.PushBack({ 0, 0, 0, 0 });
	jump_roll_right.PushBack({ 0, 0, 0, 0 });
	jump_roll_right.loop = false;
	jump_roll_right.speed = 0.3f;	
	
	jump_roll_right.PushBack({ 0, 0, 0, 0 });
	jump_roll_right.PushBack({ 0, 0, 0, 0 });
	jump_roll_right.loop = false;
	jump_roll_right.speed = 0.3f;

	killed.PushBack({ 0, 0, 0, 0 });
	killed.PushBack({ 0, 0, 0, 0 });
	killed.loop = false;
	killed.speed = 0.3f;
}

ModulePlayer::~ModulePlayer()
{}

// Load assets
bool ModulePlayer::Start()
{
	LOG("Loading player");

	graphics = App->textures->Load("rtype/ship.png");
	current_animation = &idle;

	destroyed = false;
	position.x = 150;
	position.y = 120;

	col = App->collision->AddCollider({position.x, position.y, 32, 16}, COLLIDER_PLAYER, this);

	return true;
}

// Unload assets
bool ModulePlayer::CleanUp()
{
	LOG("Unloading player");

	App->textures->Unload(graphics);
	App->collision->EraseCollider(col);

	return true;
}

// Update: draw background
update_status ModulePlayer::Update()
{

	int speed = 0;

	if (destroyed == false){
		if (state == NOT_JUMPING) {

			if ((App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_REPEAT) && App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_IDLE)
			{
				speed = 1;

				if (current_animation != &right)
				{
					right.Reset();
					current_animation = &right;
				}
			}

			else if ((App->input->keyboard[SDL_SCANCODE_A]) == KEY_STATE::KEY_REPEAT && App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_IDLE)
			{
				speed = -1;
				if (current_animation != &left)
				{
					left.Reset();
					current_animation = &left;
				}
			}

			else if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT && App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_IDLE &&
				App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_IDLE)
			{
				if (current_animation != &crouched_idle)
				{
					crouched_idle.Reset();
					current_animation = &crouched_idle;
				}
			}

			else if ((App->input->keyboard[SDL_SCANCODE_A]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT))
			{
				if (current_animation != &crouched_left)
				{
					crouched_left.Reset();
					current_animation = &crouched_left;
				}
			}

			else if ((App->input->keyboard[SDL_SCANCODE_D]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT))
			{
				if (current_animation != &crouched_right)
				{
					crouched_right.Reset();
					current_animation = &crouched_right;
				}
			}

			else if ((App->input->keyboard[SDL_SCANCODE_A]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_C] == KEY_STATE::KEY_DOWN
				&& !(App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)))
			{

				state = JUMP_LEFT;
				speed = -2;
				if (current_animation != &jump_roll_left)
				{
					jump_roll_left.Reset();
					current_animation = &jump_roll_left;
				}
			}

			else if ((App->input->keyboard[SDL_SCANCODE_D]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_C] == KEY_STATE::KEY_DOWN
				&& !(App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)))
			{

				state = JUMP_RIGHT;
				speed = 2;
				if (current_animation != &jump_roll_right)
				{
					jump_roll_right.Reset();
					current_animation = &jump_roll_right;
				}
			}

			else if ((App->input->keyboard[SDL_SCANCODE_A]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_C] == KEY_STATE::KEY_DOWN
				&& (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)))
			{

				state = JUMP_LEFT;
				speed = -2;
				if (current_animation != &crouched_roll_left)
				{
					crouched_roll_left.Reset();
					current_animation = &crouched_roll_left;
				}
			}

			else if ((App->input->keyboard[SDL_SCANCODE_D]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_C] == KEY_STATE::KEY_DOWN
				&& (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)))
			{

				state = JUMP_RIGHT;
				speed = 2;
				if (current_animation != &crouched_roll_right)
				{
					crouched_roll_right.Reset();
					current_animation = &crouched_roll_right;
				}
			}
			else if (App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_IDLE
				&& App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_IDLE && App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_IDLE){
				current_animation = &idle;
			}
			else{
				current_animation = &idle;
			}
		}
		else{
			if (state == JUMP_LEFT){
				speed = -2;
			}
			else{
				speed = 2;
			}
		}


		if ((position.x + speed) < (SCREEN_WIDTH - 30) && (position.x + speed) > 0){
			position.x += speed;
		}

		if (current_animation->Finished() && state != NOT_JUMPING){
			state = NOT_JUMPING;
		}

		col->SetPos(position.x, position.y);

	}

	// Draw everything --------------------------------------
	if(destroyed == false)
		App->render->Blit(graphics, position.x, position.y, &(current_animation->GetCurrentFrame()));

	return UPDATE_CONTINUE;
}


void ModulePlayer::OnCollision(Collider* c1, Collider* c2)
{
	if(c1 == col && destroyed == false && App->fade->IsFading() == false)
	{
		App->fade->FadeToBlack((Module*)App->scene_space, (Module*)App->scene_intro);

		current_animation = &killed;

		destroyed = true;
	}
}