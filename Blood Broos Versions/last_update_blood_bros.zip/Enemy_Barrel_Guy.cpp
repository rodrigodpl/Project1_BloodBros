#include "Application.h"
#include "Enemy_Barrel_Guy.h"
#include "Path.h"
#include "ModuleCollision.h"
#include "p2Point.h"
#include "ModuleParticles.h"

Enemy_Barrel_Guy::Enemy_Barrel_Guy(int x, int y) : Enemy(x, y)
{
	walking.PushBack({ 5, 72, 21, 22 });
	walking.PushBack({ 5, 72, 21, 22 });
	walking.PushBack({ 5, 72, 21, 22 });
	walking.speed = 0.1f;

	protect.PushBack({ 5, 72, 21, 22 });
	protect.PushBack({ 5, 72, 21, 22 });
	protect.PushBack({ 5, 72, 21, 22 });
	protect.speed = 0.1f;

	shooting.PushBack({ 5, 72, 21, 22 });
	shooting.PushBack({ 5, 72, 21, 22 });
	shooting.PushBack({ 5, 72, 21, 22 });
	shooting.speed = 0.1f;

	collider = App->collision->AddCollider({ 0, 0, 24, 24 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	orig_pos.x = x;
	orig_pos.y = y;

	Barrel_Guy_path.PushBack({ -1, 0 }, 50, &walking);
	Barrel_Guy_path.PushBack({ 0, 0 }, 100, &shooting);
	Barrel_Guy_path.PushBack({ 0, 0 }, 150, &protect);
	Barrel_Guy_path.PushBack({ -1, 0 }, 50, &walking);

}

void Enemy_Barrel_Guy::Update()
{

	position = orig_pos + Barrel_Guy_path.GetCurrentSpeed(&animation);
	if (animation == &protect && !(is_protecting)){
		is_protecting = true;
	}
	else if(animation != &protect && is_protecting){
		is_protecting = false;
	}

	if (animation == &shooting && !(has_shot)){
		App->particles->AddParticle(App->particles->enemy_shot, position.x, position.y, COLLIDER_ENEMY_SHOT, 100);
		has_shot = true;
	}
	else if (animation != &shooting){
		has_shot = false;
	}
}

void Enemy_Barrel_Guy::Die(){

	App->particles->AddParticle(App->particles->barrel_guy_dying, position.x, position.y);


}