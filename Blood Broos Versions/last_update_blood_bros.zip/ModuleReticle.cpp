#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleParticles.h"
#include "ModuleCollision.h"
#include "ModuleRender.h"
#include "ModuleReticle.h"


ModuleReticle::ModuleReticle()
{
	graphics = NULL;
	current_animation = &idle;

	position.x = 150;
	position.y = 80;

	// idle animation (just the ship)
	idle.PushBack({ 22, 27, 57, 41 });
	idle.PushBack({ 124, 27, 55, 40 });
	idle.speed = 0.2f;

}

ModuleReticle::~ModuleReticle()
{}

// Load assets
bool ModuleReticle::Start()
{
	LOG("Loading reticle");

	graphics = App->textures->Load("rtype/ship.png");

	ret_col = App->collision->AddCollider({ position.x, position.y, 50, 50 }, COLLIDER_PLAYER_SHOT);

	return true;
}

// Unload assets
bool ModuleReticle::CleanUp()
{
	LOG("Unloading reticle");

	App->textures->Unload(graphics);

	App->collision->EraseCollider(ret_col);

	return true;
}

// Update: draw background
update_status ModuleReticle::Update()
{
	int xspeed = 0;
	int yspeed = 0;

	if (App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_REPEAT)
	{
		xspeed = 2;
	}

	if (App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_REPEAT)
	{
		xspeed = -2;
	}

	if (App->input->keyboard[SDL_SCANCODE_W] == KEY_STATE::KEY_REPEAT)
	{
		yspeed = -2;
	}

	if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)
	{
		yspeed = 2;
	}

	if (position.x + xspeed > 0 && position.x + xspeed < SCREEN_WIDTH - 30){
		position.x += xspeed;
	}

	if (position.y + yspeed > 0 && position.y + yspeed < SCREEN_HEIGHT - 30){
		position.y += yspeed;
	}

	// TODO 3: Shoot lasers when the player hits SPACE

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == KEY_STATE::KEY_REPEAT)
	{
		App->particles->AddParticle(App->particles->explosion, position.x + 20, position.y);
		shooting = true;
	}
	else{
		shooting = false;
	}



	// Draw everything --------------------------------------

	App->render->Blit(graphics, position.x, position.y, &(current_animation->GetCurrentFrame()));

	return UPDATE_CONTINUE;
}