#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleAudio.h"
#include "ModuleInput.h"
#include "ModuleRender.h"
#include "ModuleFadeToBlack.h"
#include "ModuleScoreScreen.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModuleScoreScreen::ModuleScoreScreen()
{}

ModuleScoreScreen::~ModuleScoreScreen()
{}

// Load assets
bool ModuleScoreScreen::Start()
{
	LOG("Loading space intro");

	background = App->textures->Load("scorescreen.png");

	App->audio->PlayMusic("rtype/intro.ogg", 1.0f);
	fx = App->audio->LoadFx("rtype/starting.wav");
	App->render->camera.x = App->render->camera.y = 0;

	return true;
}

// UnLoad assets
bool ModuleScoreScreen::CleanUp()
{
	LOG("Unloading space scene");

	App->textures->Unload(background);
	App->audio->UnLoadFx(fx);

	return true;
}

// Update: draw background
update_status ModuleScoreScreen::Update()
{
	App->render->Blit(background, 0, 0, NULL);

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == KEY_DOWN && App->fade->IsFading() == false)
	{
		App->fade->FadeToBlack(this, (Module*)App->scene_intro);
		App->audio->PlayFx(fx);
	}

	return UPDATE_CONTINUE;
}