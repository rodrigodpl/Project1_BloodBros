#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleAudio.h"
#include "ModuleRender.h"
#include "ModulePlayer.h"
#include "ModuleCollision.h"
#include "ModuleParticles.h"
#include "ModuleEnemies.h"
#include "ModuleReticle.h"
#include "ModuleFadeToBlack.h"
#include "ModuleScenario.h"
#include "ModuleSceneSpace.h"
#include "SDL/include/SDL.h"


ModuleSceneSpace::ModuleSceneSpace()
{}

ModuleSceneSpace::~ModuleSceneSpace()
{}

// Load assets
bool ModuleSceneSpace::Start()
{
	LOG("Loading space scene");
	
	background = App->textures->Load("background.png");

	App->player->Enable();
	App->particles->Enable();
	App->collision->Enable();
	App->enemies->Enable();
	App->reticle->Enable();
	App->scenario->Enable();

	App->audio->PlayMusic("rtype/stage1.ogg", 1.0f);
	
	// Colliders ---


	// Enemies ---
	loop_enemies();      // first loop = first wave;
	defeated_enemies = 0;
	// TODO 1: Add a new wave of red birds
	App->scenario->AddElement(DESTROYABLE_WALL, 50, 50);
	App->scenario->AddElement(DESTROYABLE_BOTTLE, 200, 370);
	App->scenario->AddElement(DESTROYABLE_BOTTLE, 300, 370);
	App->scenario->AddElement(DESTROYABLE_BOTTLE, 400, 370);
	App->scenario->AddElement(DESTROYABLE_BOTTLE, 500, 370);
	App->scenario->AddElement(DESTROYABLE_BOTTLE, 600, 370);
	App->scenario->AddElement(DESTROYABLE_LIGHT, 400, 0);
	App->scenario->AddElement(DESTROYABLE_LIGHT, 100, 0);


	return true;
}

// UnLoad assets
bool ModuleSceneSpace::CleanUp()
{
	LOG("Unloading space scene");

 	App->textures->Unload(background);

	App->enemies->Disable();
	App->collision->Disable();
	App->particles->Disable();
	App->player->Disable();
	App->reticle->Disable();
	App->scenario->Disable();

	return true;
}

// Update: draw background
update_status ModuleSceneSpace::Update()
{
	if (defeated_enemies >= ENEMY_NUM_STG1){
		App->fade->FadeToBlack(this, (Module*)App->scene_score);
	}

	current_level_time = SDL_GetTicks() - init_level_time;

	if (current_level_time > 4000 && released_enemies[0] == false){
		App->enemies->AddEnemy(INDIAN_001, 100, 100);
		released_enemies[0] = true;
	}

	if (current_level_time > 6000 && released_enemies[1] == false){
		App->enemies->AddEnemy(INDIAN_002, 100, 100);
		released_enemies[1] = true;
	}

	if (current_level_time > 10000 && released_enemies[2] == false){
		App->enemies->AddEnemy(BARREL_GUY, 100, 100);
		released_enemies[2] = true;
	}

	if (current_level_time > 25000){
		loop_enemies();

	}

	// Draw everything --------------------------------------
	App->render->Blit(background, 0, 0, NULL);
	
	return UPDATE_CONTINUE;
}

void ModuleSceneSpace::loop_enemies(){

	uint i;
	for (i = 0; i < WAVE_NUM_OF_ENEMIES; i++){
		released_enemies[i] = false;
	}


	init_level_time = SDL_GetTicks();

}

