#include "Application.h"
#include "Enemy_indian_002.h"
#include "Path.h"
#include "ModuleCollision.h"
#include "p2Point.h"
#include "ModuleParticles.h"

Enemy_Indian_002::Enemy_Indian_002(int x, int y) : Enemy(x, y)
{
	walking.PushBack({ 5, 72, 21, 22 });
	walking.PushBack({ 5, 72, 21, 22 });
	walking.PushBack({ 5, 72, 21, 22 });
	walking.speed = 0.1f;

	shooting.PushBack({ 5, 72, 21, 22 });
	shooting.PushBack({ 5, 72, 21, 22 });
	shooting.PushBack({ 5, 72, 21, 22 });
	shooting.speed = 0.1f;

	collider = App->collision->AddCollider({ 0, 0, 24, 24 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	orig_pos.x = x;
	orig_pos.y = y;


	Indian_002_path.PushBack({ -1, 0 }, 50, &walking);
	Indian_002_path.PushBack({ 0, 0 }, 50, &shooting);
	Indian_002_path.PushBack({ -1, 0 }, 50, &walking);

}

void Enemy_Indian_002::Update()
{

	position = orig_pos + Indian_002_path.GetCurrentSpeed(&animation);

	if (animation == &shooting && !(has_shot)){
		App->particles->AddParticle(App->particles->enemy_shot, position.x, position.y, COLLIDER_ENEMY_SHOT, 100);
		has_shot = true;
	}
	else if (animation != &shooting){
		has_shot = false;
	}
}
