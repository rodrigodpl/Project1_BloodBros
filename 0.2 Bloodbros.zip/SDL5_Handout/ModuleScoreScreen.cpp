#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleRender.h"
#include "ModuleScoreScreen.h"
#include "ModuleFadeToBlack.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA


ModuleScoreScreen::ModuleScoreScreen()
{



	// Background / sky
	background.x = 0;
	background.y = 0;
	background.w = SCREEN_WIDTH;
	background.h = SCREEN_HEIGHT;


	// for moving the foreground
	foreground_pos = 0;

}

ModuleScoreScreen::~ModuleScoreScreen()
{}

// Load assets
bool ModuleScoreScreen::Start()
{
	LOG("Loading welcome screen");

	graphics = App->textures->Load("score_screen.png");

	App->modules[6]->Enable();


	// TODO 1: Enable (and properly disable) the player module

	return true;
}

// UnLoad assets
bool ModuleScoreScreen::CleanUp()
{
	LOG("Unloading score screen");

	App->modules[6]->Disable();


	return true;
}

// Update: draw background
update_status ModuleScoreScreen::Update()
{
	// Calculate boat Y position -----------------------------


	// Draw everything --------------------------------------
	App->render->Blit(graphics, 0, 0, &background, 0.75f); // sea and sky



	// TODO 3: make so pressing SPACE the HONDA stage is loaded

	if (App->input->keyboard[SDL_SCANCODE_SPACE]){
		App->fade->FadeToBlack(App->modules[6], App->modules[4], 1);
	}
	return UPDATE_CONTINUE;
}