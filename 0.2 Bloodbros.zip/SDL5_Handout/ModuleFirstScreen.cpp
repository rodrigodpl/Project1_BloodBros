#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleRender.h"
#include "ModuleFirstScreen.h"
#include "ModuleFadeToBlack.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA


ModuleFirstScreen::ModuleFirstScreen()
{



	// Background / sky
	background.x = 0;
	background.y = 0;
	background.w = SCREEN_WIDTH;
	background.h = SCREEN_HEIGHT;


	// for moving the foreground
	foreground_pos = 0;

}

ModuleFirstScreen::~ModuleFirstScreen()
{}

// Load assets
bool ModuleFirstScreen::Start()
{
	LOG("Loading welcome screen");

	graphics = App->textures->Load("firststage_screen.png");

	App->modules[5]->Enable();


	// TODO 1: Enable (and properly disable) the player module

	return true;
}

// UnLoad assets
bool ModuleFirstScreen::CleanUp()
{
	LOG("Unloading first screen");

	App->modules[5]->Disable();


	return true;
}

// Update: draw background
update_status ModuleFirstScreen::Update()
{
	// Calculate boat Y position -----------------------------


	// Draw everything --------------------------------------
	App->render->Blit(graphics, 0, 0, &background, 0.75f); // sea and sky



	// TODO 3: make so pressing SPACE the HONDA stage is loaded

	if (App->input->keyboard[SDL_SCANCODE_SPACE]){
		App->fade->FadeToBlack(App->modules[5], App->modules[6], 1);
	}
	return UPDATE_CONTINUE;
}