#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleRender.h"
#include "ModuleWelcomeScreen.h"
#include "ModuleFadeToBlack.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA


ModuleWelcomeScreen::ModuleWelcomeScreen()
{



	// Background / sky
	background.x = 0;
	background.y = 0;
	background.w = SCREEN_WIDTH;
	background.h = SCREEN_HEIGHT;



	// for moving the foreground
	foreground_pos = 0;

}

ModuleWelcomeScreen::~ModuleWelcomeScreen()
{}

// Load assets
bool ModuleWelcomeScreen::Start()
{
	LOG("Loading welcome screen");
	
	graphics = App->textures->Load("welcome_screen.png");

	App->modules[4]->Enable();

	
	// TODO 1: Enable (and properly disable) the player module
	
	return true;
}

// UnLoad assets
bool ModuleWelcomeScreen::CleanUp()
{
	LOG("Unloading welcome screen");

	App->modules[4]->Disable();


	return true;
}

// Update: draw background
update_status ModuleWelcomeScreen::Update()
{
	// Calculate boat Y position -----------------------------


	// Draw everything --------------------------------------
	App->render->Blit(graphics, 0, 0, &background, 0.75f); // sea and sky


	
	// TODO 3: make so pressing SPACE the HONDA stage is loaded

	if (App->input->keyboard[SDL_SCANCODE_SPACE]){
		App->fade->FadeToBlack(App->modules[4], App->modules[5]);
	}
	return UPDATE_CONTINUE;
}