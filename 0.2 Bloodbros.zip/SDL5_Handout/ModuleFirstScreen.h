#ifndef __MODULEFIRSTSCREEN_H__
#define __MODULEFIRSTSCREEN_H__

#include "Module.h"
#include "Animation.h"
#include "Globals.h"

struct SDL_Texture;

class ModuleFirstScreen : public Module
{
public:
	ModuleFirstScreen();
	~ModuleFirstScreen();

	bool Start();
	update_status Update();
	bool CleanUp();

public:

	SDL_Texture* graphics = nullptr;
	SDL_Rect background;

	float foreground_pos;
};

#endif // __MODULEFIRSTSCREEN_H__