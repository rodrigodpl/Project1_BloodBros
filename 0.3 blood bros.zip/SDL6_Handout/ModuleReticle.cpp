#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleParticles.h"
#include "ModuleRender.h"
#include "ModuleReticle.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModuleReticle::ModuleReticle()
{
	graphics = NULL;
	current_animation = &idle;

	position.x = 150;
	position.y = 80;

	// idle animation (just the ship)
	idle.PushBack({36, 48, 129, 101});
	idle.PushBack({277, 47, 129, 101});
	idle.speed = 0.3f;

}

ModuleReticle::~ModuleReticle()
{}

// Load assets
bool ModuleReticle::Start()
{
	LOG("Loading reticle");

	graphics = App->textures->Load("reticle_sprites.png");

	return true;
}

// Unload assets
bool ModuleReticle::CleanUp()
{
	LOG("Unloading reticle");

	App->textures->Unload(graphics);

	return true;
}

// Update: draw background
update_status ModuleReticle::Update()
{
	int speed = 2;



	if (App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_REPEAT)
	{
		position.x += speed;
	}

	if (App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_REPEAT)
	{
		position.x -= speed;
	}
	if (App->input->keyboard[SDL_SCANCODE_W] == KEY_STATE::KEY_REPEAT)
	{
		position.y -= speed;
	}

	if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)
	{
		position.y += speed;
	}

	// TODO 3: Shoot lasers when the player hits SPACE

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == KEY_STATE::KEY_DOWN)
	{
		App->particles->AddParticle(App->particles->laser, position.x + 20, position.y);
	}



	// Draw everything --------------------------------------

	App->render->Blit(graphics, position.x, position.y, &(current_animation->GetCurrentFrame()));

	return UPDATE_CONTINUE;
}