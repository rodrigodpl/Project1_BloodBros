Gente en la version 0.3 falta: 

	- Que se pueda pasar al segundo mapa. 
	- Yo (roger)acabare de hacer bien los sprites de cuando se mueve para los lados manyana. 
	- Poner la musica.
	- Si alguien sabe hacerlo: hacer que cuando se este apretando el boton de estar agachado el jugador no se mueva, solo la mirilla. 