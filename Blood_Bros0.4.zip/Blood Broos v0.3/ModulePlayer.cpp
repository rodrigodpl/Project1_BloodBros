#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleParticles.h"
#include "ModuleRender.h"
#include "ModulePlayer.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModulePlayer::ModulePlayer()
{
	graphics = NULL;
	current_animation = NULL;

	position.x = 150;
	position.y = 110;

	// Initial position of the player
	idle.PushBack({70, 79, 39, 76});

	// Move left
	left.PushBack({205, 24, 34, 94});
	left.PushBack({159, 24, 34, 94});
	left.PushBack({0, 0, 0, 0});
	left.PushBack({0, 0, 0, 0});
	left.PushBack({0, 0, 0, 0});
	left.PushBack({0, 0, 0, 0});
	left.PushBack({0, 0, 0, 0});
	left.PushBack({0, 0, 0, 0});
	left.loop = false;
	left.speed = 0.3f;

	// Move right
	right.PushBack({83, 18, 38, 77});
	right.PushBack({133, 18, 43, 73});
	right.PushBack({0, 0, 0, 0});
	right.PushBack({0, 0, 0, 0});
	right.PushBack({0, 0, 0, 0});
	right.PushBack({0, 0, 0, 0});
	right.PushBack({0, 0, 0, 0});
	right.PushBack({0, 0, 0, 0});
	right.loop = false;
	right.speed = 0.3f;

	left.PushBack({ 0, 0, 0, 0 });
	left.PushBack({ 0, 0, 0, 0 });
	left.PushBack({ 0, 0, 0, 0 });
	left.loop = false;
	left.speed = 0.3f;


	crouched_idle.PushBack({ 0, 0, 0, 0 });
	crouched_idle.PushBack({ 0, 0, 0, 0 });
	crouched_idle.loop = false;
	crouched_idle.speed = 0.3f;


	crouched_left.PushBack({ 0, 0, 0, 0 });
	crouched_left.PushBack({ 0, 0, 0, 0 });
	crouched_left.loop = false;
	crouched_left.speed = 0.3f;


	crouched_right.PushBack({ 0, 0, 0, 0 });
	crouched_right.PushBack({ 0, 0, 0, 0 });
	crouched_right.loop = false;
	crouched_right.speed = 0.3f;


	crouched_roll_right.PushBack({ 0, 0, 0, 0 });
	crouched_roll_right.PushBack({ 0, 0, 0, 0 });
	crouched_roll_right.loop = false;
	crouched_roll_right.speed = 0.3f;
	

	crouched_roll_right.PushBack({ 0, 0, 0, 0 });
	crouched_roll_right.PushBack({ 0, 0, 0, 0 });
	crouched_roll_right.loop = false;
	crouched_roll_right.speed = 0.3f;


	jump_roll_right.PushBack({ 0, 0, 0, 0 });
	jump_roll_right.PushBack({ 0, 0, 0, 0 });
	jump_roll_right.loop = false;
	jump_roll_right.speed = 0.3f;
	
	
	jump_roll_right.PushBack({ 0, 0, 0, 0 });
	jump_roll_right.PushBack({ 0, 0, 0, 0 });
	jump_roll_right.loop = false;
	jump_roll_right.speed = 0.3f;


	killed.PushBack({ 0, 0, 0, 0 });
	killed.PushBack({ 0, 0, 0, 0 });
	killed.loop = false;
	killed.speed = 0.3f;

}

ModulePlayer::~ModulePlayer()
{}

// Load assets
bool ModulePlayer::Start()
{
	LOG("Loading player");

	graphics = App->textures->Load("spritesheet_cowboy.png");

	return true;
}

// Unload assets
bool ModulePlayer::CleanUp()
{
	LOG("Unloading player");

	App->textures->Unload(graphics);

	return true;
}

// Update: draw background
update_status ModulePlayer::Update()
{

	if (!isjumping){

		if ((App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_REPEAT) && !(App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT))
		{
			speed = 1;

			if (current_animation != &right)
			{
				right.Reset();
				current_animation = &right;
			}
		}

		if ((App->input->keyboard[SDL_SCANCODE_A]) == KEY_STATE::KEY_REPEAT && !(App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT))
		{
			speed = -1;
			if (current_animation != &left)
			{
				left.Reset();
				current_animation = &left;
			}
		}

		if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)
		{
			if (current_animation != &crouched_idle)
			{
				crouched_idle.Reset();
				current_animation = &crouched_idle;
			}
		}

		if ((App->input->keyboard[SDL_SCANCODE_A]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT))
		{
			if (current_animation != &crouched_left)
			{
				crouched_left.Reset();
				current_animation = &crouched_left;
			}
		}

		if ((App->input->keyboard[SDL_SCANCODE_D]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT))
		{
			if (current_animation != &crouched_right)
			{
				crouched_right.Reset();
				current_animation = &crouched_right;
			}
		}

		if ((App->input->keyboard[SDL_SCANCODE_A]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_C] == KEY_STATE::KEY_DOWN
			&& !(App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)))
		{

			isjumping = true;
			speed = -2;

			if (current_animation != &jump_roll_left)
			{
				jump_roll_left.Reset();
				current_animation = &jump_roll_left;
			}
		}

		if ((App->input->keyboard[SDL_SCANCODE_D]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_C] == KEY_STATE::KEY_DOWN
			&& !(App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)))
		{

			isjumping = true;
			speed = 2;

			if (current_animation != &jump_roll_right)
			{
				jump_roll_right.Reset();
				current_animation = &jump_roll_right;
			}
		}

		if ((App->input->keyboard[SDL_SCANCODE_A]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_C] == KEY_STATE::KEY_DOWN
			&& (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)))
		{


			isjumping = true;
			speed = -2;

			if (current_animation != &crouched_roll_left)
			{
				crouched_roll_left.Reset();
				current_animation = &crouched_roll_left;
			}
		}

		if ((App->input->keyboard[SDL_SCANCODE_D]) == KEY_STATE::KEY_REPEAT && (App->input->keyboard[SDL_SCANCODE_C] == KEY_STATE::KEY_DOWN
			&& (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)))
		{
			
			isjumping = true;
			speed = 2;
			
			position.x += speed;
			if (current_animation != &crouched_roll_right)
			{
				crouched_roll_right.Reset();
				current_animation = &crouched_roll_right;
			}
		}

		if (App->input->keyboard[SDL_SCANCODE_K] == KEY_STATE::KEY_DOWN)
		{
			killed.Reset();
			current_animation = &killed;
		}

		if (App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_IDLE
			&& App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_IDLE && App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_IDLE){
			speed = 0;
			current_animation = &idle;
		}

	}

	if (position.x + speed > 0 && position.x + speed < SCREEN_WIDTH){
		position.x += speed;
	}

	if (current_animation->Finished()){
		isjumping = false;
	}

	// Draw everything --------------------------------------

	App->render->Blit(graphics, position.x, position.y, &(current_animation->GetCurrentFrame()));

	return UPDATE_CONTINUE;
}