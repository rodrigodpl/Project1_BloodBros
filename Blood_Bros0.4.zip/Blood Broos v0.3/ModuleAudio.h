
#ifndef _MODULEAUDIO_H_
#define _MODULEAUDIO_H_

#define MAX_FX 10
#define MAX_MUSIC 10

#include "Module.h"
#include "Globals.h"
#include "SDL_mixer\include\SDL_mixer.h"

enum samples{
	BASIC_SHOT_SOUND,
	SHOTGUN_SHOT,
	PLANE_SHOT
};

enum tracks{

	INTRO_SONG,
	FIRST_STAGE_SONG,
	SECOND_STAGE_SONG



};

class ModuleAudio : public Module{
public:
	ModuleAudio();
	~ModuleAudio();

	bool Init();
	bool Start();
	update_status Update();
	bool CleanUp();
	void changemusic(int scene);
	void playsound(int sound);

public:
	Mix_Chunk* audio[MAX_FX];
	Mix_Music* music[MAX_MUSIC];
};


#endif
