#include "ModuleAudio.h"
#include "Module.h"
#include "Application.h"
#include "SDL_mixer\include\SDL_mixer.h"

ModuleAudio::ModuleAudio(){
	Mix_OpenAudio(44100, AUDIO_S16SYS, 1, 1024);
}
ModuleAudio::~ModuleAudio(){
	Mix_CloseAudio();
}

bool ModuleAudio::Init(){

	for (int i = 0; i < MAX_FX; i++){
		audio[i] = NULL;
	}

	for (int i = 0; i < MAX_MUSIC; i++){
		music[i] = NULL;
	}
}

bool ModuleAudio::Start(){

	audio[BASIC_SHOT_SOUND] = Mix_LoadWAV("example00.wav");
	audio[SHOTGUN_SHOT] = Mix_LoadWAV("example01.wav");
	audio[PLANE_SHOT] = Mix_LoadWAV("example02.wav");
	audio[3] = Mix_LoadWAV("example03.wav");
	audio[4] = Mix_LoadWAV("example04.wav");

	music[INTRO_SONG] = Mix_LoadMUS("musicexample00.wav");
	music[FIRST_STAGE_SONG] = Mix_LoadMUS("musicexample01.wav");
	music[SECOND_STAGE_SONG] = Mix_LoadMUS("musicexample02.wav");
	music[3] = Mix_LoadMUS("musicexample03.wav");
	music[4] = Mix_LoadMUS("musicexample04.wav");


	Mix_PlayMusic(music[0], -1);
}


bool ModuleAudio::CleanUp(){

	for (int i = 0; i < MAX_FX; i++){
		if (audio[i] != NULL){
			Mix_FreeChunk(audio[i]);
		}
	}

	for (int i = 0; i < MAX_MUSIC; i++){
		if (music[i] != NULL){
			Mix_FreeMusic(music[i]);
		}
	}

}


void ModuleAudio::changemusic(int scene){

	Mix_FadeOutMusic(1000);
	Mix_FadeInMusic(music[scene], -1, 1000);
}

void ModuleAudio::playsound(int sound){

	Mix_PlayChannel(-1, audio[sound], 1);




}