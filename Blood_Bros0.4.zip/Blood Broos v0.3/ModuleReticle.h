#ifndef __MODULERETICLE_H__
#define __MDOULERETICLE_H__

#include "Module.h"
#include "Animation.h"
#include "p2Point.h"

struct SDL_Texture;
class ModuleCollision;

class ModuleReticle : public Module
{
public:
	ModuleReticle();
	~ModuleReticle();

	bool Start();
	update_status Update();
	void OnCollision(Collider* c1, Collider* c2);
	bool CleanUp();

public:

	SDL_Texture* graphics = nullptr;
	Animation* current_animation = nullptr;
	Animation idle;
	Collider* reticle_collider;
	iPoint position;
};

#endif